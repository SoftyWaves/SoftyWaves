function sentOTP() {
  const email = document.getElementById('email');
  conts otpverify = document.getElementById('otpverify')[0];

  Let emailbody = Math.floor(Math.random() * 10000);

  Let emailbody = '<h2>Your OTP is </h2>${otp_val';
  Email.send({
    SecureToken : " 72ed98d0-63c9-4b0a-876d-396f0894b57a",
    To : email.value,
    From : "softwavesinfo@gmail.com",
    Subject : "Email OTP",
    Body : emailbody,
  }).then(

    message => {
      if (message === "OK")
        alert("OTP sent to your email" + email.value);

      otpverify.style.display = "flex";
      const otp_inp = document.getElementById('otp_inp');
      const otp_btn = document.getElementById('otp_btn');

      otp_btn.addEventListener('click', () => {
        if (otp_inp.value === otp_val) {
          alert("Email Address verified");
        }
        else {
          alert("Invalid OTP");
        }
      })
    }
      
  )
};
}